<?php 
$options = array();

$options[] = array(
				'id'		=> 'gravatar_email'
				,'label'	=> esc_html__('Gravatar Email Address', 'oblerthemes')
				,'desc'		=> esc_html__('Enter an e-mail address to display Gravatar profile image instead of using the "Featured Image". You have to remove the "Featured Image".', 'oblerthemes')
				,'type'		=> 'text'
			);
			
$options[] = array(
				'id'		=> 'byline'
				,'label'	=> esc_html__('Byline', 'oblerthemes')
				,'desc'		=> esc_html__('Enter a byline for the customer giving this testimonial. For example: CEO of Theme-Sky', 'oblerthemes')
				,'type'		=> 'text'
			);
			
$options[] = array(
				'id'		=> 'url'
				,'label'	=> esc_html__('URL', 'oblerthemes')
				,'desc'		=> esc_html__('Enter an URL that applies to this customer. For example: http://theme-sky.com/', 'oblerthemes')
				,'type'		=> 'text'
			);
			
$options[] = array(
				'id'		=> 'rating'
				,'label'	=> esc_html__('Rating', 'oblerthemes')
				,'desc'		=> ''
				,'type'		=> 'select'
				,'options'	=> array(
						'-1'	=> esc_html__('no rating', 'oblerthemes')
						,'1'	=> esc_html__('1 star', 'oblerthemes')
						,'1.5'	=> esc_html__('1.5 star', 'oblerthemes')
						,'2'	=> esc_html__('2 stars', 'oblerthemes')
						,'2.5'	=> esc_html__('2.5 stars', 'oblerthemes')
						,'3'	=> esc_html__('3 stars', 'oblerthemes')
						,'3.5'	=> esc_html__('3.5 stars', 'oblerthemes')
						,'4'	=> esc_html__('4 stars', 'oblerthemes')
						,'4.5'	=> esc_html__('4.5 stars', 'oblerthemes')
						,'5'	=> esc_html__('5 stars', 'oblerthemes')
				)
			);
?>