<?php 
$options = array();
		
$options[] = array(
				'id'		=> 'portfolio_url'
				,'label'	=> esc_html__('Portfolio URL', 'oblerthemes')
				,'desc'		=> esc_html__('Enter URL to the live version of the project', 'oblerthemes')
				,'type'		=> 'text'
			);
			
$options[] = array(
				'id'		=> 'video_url'
				,'label'	=> esc_html__('Video URL', 'oblerthemes')
				,'desc'		=> esc_html__('Enter Youtube or Vimeo video URL. Display this video instead of the featured image on the detail page', 'oblerthemes')
				,'type'		=> 'text'
			);

$options[] = array(
				'id'		=> 'bg_color'
				,'label'	=> esc_html__('Background Color', 'oblerthemes')
				,'desc'		=> esc_html__('Used for the shortcode. It will display this background color on hover', 'oblerthemes')
				,'type'		=> 'colorpicker'
			);
			
$options[] = array(
				'id'		=> 'portfolio_custom_field'
				,'label'	=> esc_html__('Custom Field', 'oblerthemes')
				,'desc'		=> ''
				,'type'		=> 'select'
				,'options'	=> array(
									'0'		=> esc_html__('Default', 'oblerthemes')
									,'1'	=> esc_html__('Override', 'oblerthemes')
								)
			);
			
$options[] = array(
				'id'		=> 'portfolio_custom_field_title'
				,'label'	=> esc_html__('Custom Field Title', 'oblerthemes')
				,'desc'		=> ''
				,'type'		=> 'text'
			);
			
$options[] = array(
				'id'		=> 'portfolio_custom_field_content'
				,'label'	=> esc_html__('Custom Field Content', 'oblerthemes')
				,'desc'		=> ''
				,'type'		=> 'textarea'
			);
?>