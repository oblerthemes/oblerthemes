<?php 
$options = array();

$options[] = array(
				'id'		=> 'url'
				,'label'	=> esc_html__('URL', 'oblerthemes')
				,'desc'		=> esc_html__('Enter an URL that applies to this feature. For example: http://theme-sky.com/', 'oblerthemes')
				,'type'		=> 'text'
			);
?>